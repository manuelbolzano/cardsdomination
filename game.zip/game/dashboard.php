<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'include/db_connect.php';

$user_id = $_SESSION['user_id'];
$sql = "SELECT username, punti, profile_image FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $punti, $profile_image);
$stmt->fetch();
$stmt->close();

// Recupera il livello dell'utente in base ai punti
$level_sql = "SELECT level_number, image_url FROM levels WHERE points_required <= ? ORDER BY points_required DESC LIMIT 1";
$level_stmt = $conn->prepare($level_sql);
$level_stmt->bind_param("i", $punti);
$level_stmt->execute();
$level_stmt->bind_result($level_number, $level_image_url);
$level_stmt->fetch();
$level_stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="container">
    <?php include 'include/menu.php'; ?>
    <h1>Benvenuto, <?php echo htmlspecialchars($username); ?>!</h1>
    <p>I tuoi Punti: <?php echo htmlspecialchars($punti); ?></p>
    <?php if ($profile_image): ?>
        <div>
            <img src="<?php echo htmlspecialchars($profile_image); ?>" alt="Profile Image" style="max-width: 150px; margin-top: 10px;">
        </div>
    <?php endif; ?>
    <?php if ($level_image_url): ?>
        <div>
            <p>Livello Corrente: <?php echo htmlspecialchars($level_number); ?></p>
            <img src="<?php echo htmlspecialchars($level_image_url); ?>" alt="Level Image" style="max-width: 150px; margin-top: 10px;">
        </div>
    <?php endif; ?>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
