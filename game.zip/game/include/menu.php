<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Profilo
                </a>
                <div class="dropdown-menu" aria-labelledby="profileDropdown">
                    <a class="dropdown-item" href="dashboard.php">Profilo</a>
                    <a class="dropdown-item" href="profile.php">Modifica profilo</a>
                </div>
            </li>
            <li class="nav-item"><a class="nav-link" href="cards.php">Le mie carte</a></li>
            <li class="nav-item"><a class="nav-link" href="leaderboard.php">Classifica</a></li>
            <li class="nav-item"><a class="nav-link" href="game.php">Gioca ora</a></li>
        </ul>
    </div>
</nav>
