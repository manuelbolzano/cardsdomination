<nav>
    <ul class="nav">
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="users.php">Utenti</a></li>
        <li class="nav-item"><a class="nav-link" href="cards.php">Carte</a></li>
        <li class="nav-item"><a class="nav-link" href="manage_levels.php">Gestisci Livelli Utente</a></li>
        <li class="nav-item"><a class="nav-link" href="manage_points.php">Gestione Punteggi</a></li>
    </ul>
</nav>
