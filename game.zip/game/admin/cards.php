<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
include '../include/db_connect.php';

$sql = "SELECT * FROM cards";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cards</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1>Cards</h1>
    <?php include 'menu.php'; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Top</th>
                <th>Top-Right</th>
                <th>Right</th>
                <th>Bottom-Right</th>
                <th>Bottom</th>
                <th>Bottom-Left</th>
                <th>Left</th>
                <th>Top-Left</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><a href="edit_card.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo $row['power_top']; ?></td>
                    <td><?php echo $row['power_top_right']; ?></td>
                    <td><?php echo $row['power_right']; ?></td>
                    <td><?php echo $row['power_bottom_right']; ?></td>
                    <td><?php echo $row['power_bottom']; ?></td>
                    <td><?php echo $row['power_bottom_left']; ?></td>
                    <td><?php echo $row['power_left']; ?></td>
                    <td><?php echo $row['power_top_left']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
